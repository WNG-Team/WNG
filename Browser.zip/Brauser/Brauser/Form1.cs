﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Brauser
{
    public partial class Form1 : Form
    {

        int i = 0;
        private object textBox;

        public Form1() => InitializeComponent();
        private void new_page()
        {
            WebBrowser web = new WebBrowser();
            web.Visible = true;
            web.ScriptErrorsSuppressed = true;
            web.Dock = DockStyle.Fill;
            web.DocumentCompleted += web_DocumentCompleted;
            tabControl1.TabPages.Add("Новая страница");
            tabControl1.SelectTab(i);
            tabControl1.SelectedTab.Controls.Add(web);
            i += 1;
        }

        private void button_search(object sender, EventArgs e)
        {
            if (textBox1.Text != null)
            {
                new_page();
                ((WebBrowser)tabControl1.SelectedTab.Controls[0]).Navigate(textBox1.Text);
                textBox1.Text = "";
            }

        }

        private void button_plus(object sender, EventArgs e)
        {

            new_page();
            ((WebBrowser)tabControl1.SelectedTab.Controls[0]).Navigate("google.com");

        }

        void web_DocumentCompleted(object sender, WebBrowserDocumentCompletedEventArgs e)
        {
            tabControl1.SelectedTab.Text = ((WebBrowser)tabControl1.SelectedTab.Controls[0]).DocumentTitle;
       
        }

        private void button_minus(object sender, EventArgs e)
        {
            if (tabControl1.TabPages.Count > 1)
            {
                tabControl1.TabPages.RemoveAt(tabControl1.SelectedIndex);
                tabControl1.SelectTab(tabControl1.TabPages.Count - 1);
                i -= 1;
            }
            else Application.Exit();
        }

        private void button_last(object sender, EventArgs e)
        {
            ((WebBrowser)tabControl1.SelectedTab.Controls[0]).GoBack();
        }

        private void button_next(object sender, EventArgs e)
        {
            ((WebBrowser)tabControl1.SelectedTab.Controls[0]).GoForward();
        }

        private void button_refresh(object sender, EventArgs e)
        {
            ((WebBrowser)tabControl1.SelectedTab.Controls[0]).Refresh();
        }

        private void textBox1_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                new_page();
                ((WebBrowser)tabControl1.SelectedTab.Controls[0]).Navigate(textBox1.Text);
                textBox1.Text = "";
            }
        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
            
                new_page();
                ((WebBrowser)tabControl1.SelectedTab.Controls[0]).Navigate("google.com");
            
        }
    }
}
